#include <stdio.h>

int main()
{
  int n1=4, n2=2;
  float f1=4,f2=2;

  printf("1 + n1 / 2 * n2 = %d", 1 + n1 / 2 * n2); //5
  printf("\n");
  printf("1 + f1 / 2 * f2 = %f", 1 + f1 / 2 * f2); //5.0
  printf("\n");

  return 0;
}
