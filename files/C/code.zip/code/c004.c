#include <stdio.h>

int main()
{
  int base=2;
  int altezza=4;

  printf("La base vale: %d e l'altezza vale: %d\n",base,altezza);
  printf("L'area del rettangolo vale: %d\n",base * altezza);

  return 0;
}
