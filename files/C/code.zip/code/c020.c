#include <stdio.h>
int main()
{
  int n,somma=0;

  scanf("%d",&n);
  somma=somma+n;
  scanf("%d",&n);
  somma=somma+n;
  scanf("%d",&n);
  somma=somma+n;
  printf("%d",somma);
}
