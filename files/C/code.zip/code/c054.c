#include <stdio.h>
#define DIM 10

int main()
{
    char stringa[DIM];

    printf("Inserisci una stringa: ");
    scanf("%s",stringa);

    printf("La tua stringa: %s\n",stringa);
}
