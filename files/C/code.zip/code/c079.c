#include <stdio.h>

void messaggio();

int main() {

  messaggio();
}

void messaggio() {

  printf("\nLa mia prima funzione\n");
}
