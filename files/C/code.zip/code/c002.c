#include <stdio.h>

int main()
{
  int var=1;
  char c='a';
  printf("%d\n",var);
  printf("%c\n",c);
  return 0;
}
