#include <stdio.h>

int main()
{
  int base=2;
  int altezza=4;
  int area;

  printf("La base vale: %d\n",base);
  printf("L'altezza vale: %d\n",altezza);

  area = base * altezza;

  printf("L'area del rettangolo vale: %d\n",area);

  return 0;
}
