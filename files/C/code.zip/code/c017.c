#include <stdio.h>
int main()
{
    float x=0.1;
    int a=10,b=10;

    printf("%f ", x);


    printf("%d ", a);
    printf("%lf ", b);
}
