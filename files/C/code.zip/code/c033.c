#include <stdio.h>
int main()
{
  int n=0;

  do printf("%d ",n++);
  while(n<=9);
}
