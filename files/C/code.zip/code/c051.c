#include <stdio.h>

int main() {
char stringa[]="Elementi di informatica";
int i=0;

printf("%s",stringa);
}
