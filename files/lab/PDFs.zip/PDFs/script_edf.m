clc
inDir='/Users/matteo/Documents/GitHub/matteogithub.github.io/files/edf/';
filt_file='*.edf';
files=dir(fullfile(inDir,filt_file));

for i=1:size(files,1)
    i
    file_to_import=strcat(inDir,files(i).name);
    EEG=pop_biosig(file_to_import); 
    %ADD THE ANALYSIS
    %SAVE RESULTS
end



