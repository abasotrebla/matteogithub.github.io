%generate two random signals
%RAND returns values in the range (0-1)
%See "help rand"

% sig1=200+(-400).*rand(4096,19);%set amplitude, length and dimension (channels)
% sig2=200+(-400).*rand(4096,19);

n_sbj=5;
n_chans=19;
n_samples=4096;

mat_sig=zeros(n_sbj,n_chans,n_samples);

for i=1:size(mat_sig,1)
    
    mat_sig(i,:,:)=200+(-400).*rand(n_chans,n_samples);
    
    nomefile=strcat('my_file_',int2str(i),'.txt');
    
    dlmwrite(nomefile,squeeze(mat_sig(i,:,:)),'delimiter','\t','precision','%.2f');
    
end

%write signal to file. See "help dlmwrite"
% dlmwrite('my_sig1.txt',sig1,'delimiter','\t','precision','%.6f');
% dlmwrite('my_sig2.txt',sig2,'delimiter','\t','precision','%.6f');

%open files. See directory
dirpath='/Users/matteo/Google Drive/Lab_neuro/2019/Matlab/';
fil='*.txt';

files=dir(fullfile(dirpath,fil)); %See what 'files' contains




%Import multiple files
my_data=zeros(n_sbj,n_chans,n_samples);

for i=1:length(files) %See also 'size' function
    
    filename=fullfile(dirpath,files(i).name);
    
    my_data(i,:,:)=importdata(filename);
    %newfile=strtok(files(i).name,'.');
    %dlmwrite(strcat(newfile,'_new.txt'),my_newdata,'delimiter','\t','precision','%.6f')
end



