Fs = 256;                     % Sampling frequency
T = 1/Fs;                     % Sample time
L = 4096;                     % Length of signal
t = (0:L-1)*T;                % Time vector

%generare tre componenti sinusoidali
y1 = 10*sin(2*pi*10*t); 
y2 = 20*sin(2*pi*20*t); 
y3 = 30*sin(2*pi*30*t);
%noise=10*sin(2*pi*50*rand()*t);

y=y1+y2+y3;

[pxx,F]=pwelch(y,[],0,[],Fs);
plot(F,pxx)
xlabel('Frequency (Hz)')
ylabel('PSD ')

% plot(t,y)
% title('Signal')
% xlabel('time (seconds)')

%provare a modificare le ampiezze e/o le frequenze dei segnali
% NFFT = 2^nextpow2(L);
% Y = fft(y,NFFT)/L;
% f = Fs/2*linspace(0,1,NFFT/2+1); %intervallo delle frequenze da stampare
% 
% % Plot spettro (ampiezza) 
% figure;plot(f,2*abs(Y(1:NFFT/2+1)))
% title('Amplitude Spectrum of y')
% xlabel('Frequency (Hz)')
% ylabel('|Y(f)|')